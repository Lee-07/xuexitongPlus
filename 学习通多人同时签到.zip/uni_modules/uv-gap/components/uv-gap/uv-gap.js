(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uni_modules/uv-gap/components/uv-gap/uv-gap"],{"637d":function(t,n,a){"use strict";a.r(n);var e=a("a521"),i=a("ab29");for(var u in i)["default"].indexOf(u)<0&&function(t){a.d(n,t,(function(){return i[t]}))}(u);var o=a("828b"),r=Object(o["a"])(i["default"],e["b"],e["c"],!1,null,null,null,!1,e["a"],void 0);n["default"]=r.exports},a521:function(t,n,a){"use strict";a.d(n,"b",(function(){return e})),a.d(n,"c",(function(){return i})),a.d(n,"a",(function(){}));var e=function(){var t=this.$createElement,n=(this._self._c,this.__get_style([this.gapStyle]));this.$mp.data=Object.assign({},{$root:{s0:n}})},i=[]},ab29:function(t,n,a){"use strict";a.r(n);var e=a("dade"),i=a.n(e);for(var u in e)["default"].indexOf(u)<0&&function(t){a.d(n,t,(function(){return e[t]}))}(u);n["default"]=i.a},dade:function(t,n,a){"use strict";var e=a("47a9");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var i=e(a("0840")),u=e(a("84cf")),o=e(a("4b89")),r={name:"uv-gap",mixins:[i.default,u.default,o.default],computed:{gapStyle:function(){var t={backgroundColor:this.bgColor,height:this.$uv.addUnit(this.height),marginTop:this.$uv.addUnit(this.marginTop),marginBottom:this.$uv.addUnit(this.marginBottom)};return this.$uv.deepMerge(t,this.$uv.addStyle(this.customStyle))}}};n.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uni_modules/uv-gap/components/uv-gap/uv-gap-create-component',
    {
        'uni_modules/uv-gap/components/uv-gap/uv-gap-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("637d"))
        })
    },
    [['uni_modules/uv-gap/components/uv-gap/uv-gap-create-component']]
]);
