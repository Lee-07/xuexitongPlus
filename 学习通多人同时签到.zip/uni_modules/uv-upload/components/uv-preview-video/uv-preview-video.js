(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uni_modules/uv-upload/components/uv-preview-video/uv-preview-video"],{"01a5":function(n,e,t){"use strict";var u=t("57c1"),o=t.n(u);o.a},"1fec":function(n,e,t){"use strict";t.d(e,"b",(function(){return o})),t.d(e,"c",(function(){return c})),t.d(e,"a",(function(){return u}));var u={uvPopup:function(){return t.e("uni_modules/uv-popup/components/uv-popup/uv-popup").then(t.bind(null,"6641"))}},o=function(){var n=this.$createElement;this._self._c},c=[]},"57c1":function(n,e,t){},"83e9":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u={props:{src:{type:String,default:""},autoplay:{type:Boolean,default:!0}},data:function(){return{videoSrc:"",show:!1}},computed:{getSec:function(){return this.src||this.videoSrc}},methods:{open:function(n){this.videoSrc=n,this.$refs.popup.open()},close:function(){this.$refs.popup.close()},change:function(n){this.show=n.show}}};e.default=u},9226:function(n,e,t){"use strict";t.r(e);var u=t("1fec"),o=t("97d4");for(var c in o)["default"].indexOf(c)<0&&function(n){t.d(e,n,(function(){return o[n]}))}(c);t("01a5");var i=t("828b"),r=Object(i["a"])(o["default"],u["b"],u["c"],!1,null,"5c90ac64",null,!1,u["a"],void 0);e["default"]=r.exports},"97d4":function(n,e,t){"use strict";t.r(e);var u=t("83e9"),o=t.n(u);for(var c in u)["default"].indexOf(c)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(c);e["default"]=o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component',
    {
        'uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("9226"))
        })
    },
    [['uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component']]
]);
