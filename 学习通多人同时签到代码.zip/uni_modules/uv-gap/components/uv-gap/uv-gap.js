(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uni_modules/uv-gap/components/uv-gap/uv-gap"],{8722:function(t,e,n){"use strict";n.r(e);var i=n("89f6"),u=n("c1bc");for(var a in u)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(a);var o=n("828b"),r=Object(o["a"])(u["default"],i["b"],i["c"],!1,null,null,null,!1,i["a"],void 0);e["default"]=r.exports},"89f6":function(t,e,n){"use strict";n.d(e,"b",(function(){return i})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){}));var i=function(){var t=this.$createElement,e=(this._self._c,this.__get_style([this.gapStyle]));this.$mp.data=Object.assign({},{$root:{s0:e}})},u=[]},"8fe2":function(t,e,n){"use strict";var i=n("47a9");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var u=i(n("802e")),a=i(n("811e")),o=i(n("fb4b")),r={name:"uv-gap",mixins:[u.default,a.default,o.default],computed:{gapStyle:function(){var t={backgroundColor:this.bgColor,height:this.$uv.addUnit(this.height),marginTop:this.$uv.addUnit(this.marginTop),marginBottom:this.$uv.addUnit(this.marginBottom)};return this.$uv.deepMerge(t,this.$uv.addStyle(this.customStyle))}}};e.default=r},c1bc:function(t,e,n){"use strict";n.r(e);var i=n("8fe2"),u=n.n(i);for(var a in i)["default"].indexOf(a)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(a);e["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uni_modules/uv-gap/components/uv-gap/uv-gap-create-component',
    {
        'uni_modules/uv-gap/components/uv-gap/uv-gap-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("8722"))
        })
    },
    [['uni_modules/uv-gap/components/uv-gap/uv-gap-create-component']]
]);
