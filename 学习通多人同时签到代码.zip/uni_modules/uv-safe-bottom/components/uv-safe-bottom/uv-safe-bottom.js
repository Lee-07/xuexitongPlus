(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uni_modules/uv-safe-bottom/components/uv-safe-bottom/uv-safe-bottom"],{"1e6a":function(t,e,n){"use strict";n.r(e);var u=n("3d62"),a=n("9831");for(var o in a)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(o);n("319e");var i=n("828b"),s=Object(i["a"])(a["default"],u["b"],u["c"],!1,null,"722aa140",null,!1,u["a"],void 0);e["default"]=s.exports},2049:function(t,e,n){"use strict";var u=n("47a9");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a=u(n("802e")),o=u(n("811e")),i={name:"uv-safe-bottom",mixins:[a.default,o.default],data:function(){return{safeAreaBottomHeight:0,isNvue:!1}},computed:{style:function(){return this.$uv.deepMerge({},this.$uv.addStyle(this.customStyle))}},mounted:function(){}};e.default=i},"319e":function(t,e,n){"use strict";var u=n("e13d"),a=n.n(u);a.a},"3d62":function(t,e,n){"use strict";n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){}));var u=function(){var t=this.$createElement,e=(this._self._c,this.__get_style([this.style]));this.$mp.data=Object.assign({},{$root:{s0:e}})},a=[]},9831:function(t,e,n){"use strict";n.r(e);var u=n("2049"),a=n.n(u);for(var o in u)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(o);e["default"]=a.a},e13d:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uni_modules/uv-safe-bottom/components/uv-safe-bottom/uv-safe-bottom-create-component',
    {
        'uni_modules/uv-safe-bottom/components/uv-safe-bottom/uv-safe-bottom-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("1e6a"))
        })
    },
    [['uni_modules/uv-safe-bottom/components/uv-safe-bottom/uv-safe-bottom-create-component']]
]);
