(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["uni_modules/uv-upload/components/uv-preview-video/uv-preview-video"],{"31b2":function(n,t,e){},"5c65":function(n,t,e){"use strict";var u=e("31b2"),o=e.n(u);o.a},"6bbd":function(n,t,e){"use strict";e.r(t);var u=e("d2cb"),o=e("7d21");for(var c in o)["default"].indexOf(c)<0&&function(n){e.d(t,n,(function(){return o[n]}))}(c);e("5c65");var i=e("828b"),r=Object(i["a"])(o["default"],u["b"],u["c"],!1,null,"5c90ac64",null,!1,u["a"],void 0);t["default"]=r.exports},"7d21":function(n,t,e){"use strict";e.r(t);var u=e("dd05"),o=e.n(u);for(var c in u)["default"].indexOf(c)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(c);t["default"]=o.a},d2cb:function(n,t,e){"use strict";e.d(t,"b",(function(){return o})),e.d(t,"c",(function(){return c})),e.d(t,"a",(function(){return u}));var u={uvPopup:function(){return e.e("uni_modules/uv-popup/components/uv-popup/uv-popup").then(e.bind(null,"dfcd"))}},o=function(){var n=this.$createElement;this._self._c},c=[]},dd05:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={props:{src:{type:String,default:""},autoplay:{type:Boolean,default:!0}},data:function(){return{videoSrc:"",show:!1}},computed:{getSec:function(){return this.src||this.videoSrc}},methods:{open:function(n){this.videoSrc=n,this.$refs.popup.open()},close:function(){this.$refs.popup.close()},change:function(n){this.show=n.show}}};t.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component',
    {
        'uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('df3c')['createComponent'](__webpack_require__("6bbd"))
        })
    },
    [['uni_modules/uv-upload/components/uv-preview-video/uv-preview-video-create-component']]
]);
